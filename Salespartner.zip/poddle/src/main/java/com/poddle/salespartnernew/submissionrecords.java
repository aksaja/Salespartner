package com.poddle.salespartnernew;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class submissionrecords extends setup {
	//Click submission records 
		@Test(priority = 4)
		public void clicksubmission() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.id("submission-record")));
			click.click();
		}
		//Validate calendar button
		@Test(priority = 5)
		public void calendar() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement calendar = wait.until(ExpectedConditions.elementToBeClickable(By.id("inputDate-sizing-lg")));	
			Assert.assertTrue(calendar.isDisplayed(), "Button is not displayed");
			Assert.assertTrue(calendar.isEnabled(), "Button is not enabled");
			//Assert.assertEquals(calendar.getText(), "06/12/2024", "Button text does not match");
		}
		//Validate search button
		@Test(priority = 6)
		public void search() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement search = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));	
			Assert.assertTrue(search.isDisplayed(), "Button is not displayed");
			Assert.assertTrue(search.isEnabled(), "Button is not enabled");
			Assert.assertEquals(search.getText(), "Search", "Button text does not match");
		}
		
		//Validate the status button
		@Test(priority = 7)
		public void status() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement status = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@aria-autocomplete='list']")));	
			Assert.assertTrue(status.isDisplayed(), "Button is not displayed");
			Assert.assertTrue(status.isEnabled(), "Button is not enabled");
			Assert.assertEquals(status.getText(), "Search", "Button text does not match");
		}
		
		//Validate the table
		@Test
		public void column1() {
		List<WebElement> columns=driver.findElements(By.tagName("th"));
		int columnCount = columns.size();
		System.out.println("Number of columns" + columnCount);
		}
		
		@Test
		public void row() {
		List<WebElement> columns=driver.findElements(By.tagName("tr"));
		int columnCount = columns.size();
		System.out.println("Number of columns" + columnCount);
		}
		
		}

