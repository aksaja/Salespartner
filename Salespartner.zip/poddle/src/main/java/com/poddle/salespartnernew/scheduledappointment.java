package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class scheduledappointment extends setup{
	
	//Click the scheduled appointment
	@Test
	public void viewappointment() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='c-poin")));
        button1.click();
}
	// validate payment before paid
	@Test
	public void payment() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement paybutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='inputP")));
        Assert.assertEquals(paybutton.getText(),"https://join.poddleuat.demotown.co.uk/#/vendor-payment/f2a6fca2-545c-42dd-8d01-104556d2577b_74b7ea6c-b3c0-4644-9d3b-43f842c2f5c8","Text doest not match");

	}
}

