package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class searchforainvalid extends setup {
	//Enter a search term(business user name) and check if results are displayed.
		@Test(priority = 5)
		public void searchusername()throws InterruptedException {
	    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
		Assert.assertTrue(searchBox.isDisplayed(), "Search box is not displayed");
		Thread.sleep(500);
		
		//Enter a search user name
		String searchTerm = "Thulasi";
	    searchBox.sendKeys(searchTerm + Keys.ENTER);
	   // Thread.sleep(1000);

	    searchBox.clear();
	    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
	    pointer.click();
	   // Thread.sleep(3000);
		}

		//Enter a search term(business name) and check if results are displayed.
		@Test(priority = 6)
		public void searchbusinessname()throws InterruptedException {
	    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
		Thread.sleep(500);
		
		//Enter a search business name
		String searchTerm = "Teen fashion";
	    searchBox.sendKeys(searchTerm + Keys.ENTER);
	    Thread.sleep(1000);

	    searchBox.clear();
	    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
	    pointer.click();
	    Thread.sleep(1000);
		}

}
