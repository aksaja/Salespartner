package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class copyavailabilityM extends setup {

	//Try to copy the invalid time slot
		@Test(priority = 4)
		public void manage() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement manage = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[class='btn p-light-button'] span[class='p-label-small']")));
	        manage.click();
		}
		@Test(priority = 5)
		public void copy() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement copy = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Copy availability']")));
	        copy.click();
		}
		@Test(priority = 6)
		public void copytimeslot() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement copyb = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row my-5']//button[@class='btn p-button m-p-button w-100']")));
	        copyb.click();
		}
		@Test(priority = 7)
		public void clickokay() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement okayb = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn p-button w-100 m-p-button']")));
	        okayb.click();
		}
		
		//Copy the correct time slot
		//Click date to copy from
		@Test
		public void copyfrom() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement datec = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row input-margin-bottom']//div[@class='col-sm-8']//span[@class='input-group-text p-border-radius-right bg-white']//*[name()='svg']//*[name()='path' and contains(@d,'M2.5 4a.5.')]")));
	        datec.click();
		}
		//Select a future date
		@Test
		public void selectdate() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement selectd = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='custom-day selected']")));
	        selectd.click();
		}
	   //Click the date to copy to
		@Test
		public void copyto() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement copyto = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row']//span[@class='input-group-text p-border-radius-right bg-white']")));
	        copyto.click();
		}
	   //Select a available day
		@Test
		public void selectdate2() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement availabled = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='custom-day'][normalize-space()='30']")));
	        availabled.click();
		}
		//Click the copy time slot button
		@Test
		public void copytime() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement copyt = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row my-5']//button[@class='btn p-button m-p-button w-100']")));
	        copyt.click();
		}

}
