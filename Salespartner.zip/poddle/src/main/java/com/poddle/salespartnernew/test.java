package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import org.openqa.selenium.By;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.netty.handler.timeout.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.ArrayList;
import java.util.List;
import java.awt.datatransfer.*;
import java.awt.event.KeyEvent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import java.time.Duration;
import java.util.function.Function;
public class test {
	WebDriver driver;

	@Test(priority = 1)

	public void setupsuite()  throws InterruptedException{
	
		 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
	}	
	@Test(priority = 2)
	 public void browse() {
	 driver.get("https://www.google.com");
	 driver.get("https://sales-partner.poddleuat.demotown.co.uk/#/diary/calendar");
	 }

	@Test(priority = 3)
	public void signin4() {
						
		WebElement emailField = driver.findElement(By.id("login-email"));
		emailField.sendKeys("aksaja50@gmail.com");
		WebElement passwordField = driver.findElement(By.id("login-password"));
		passwordField.sendKeys("WgemWgem@23");
		WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
		unhidepass.click();
		WebElement rememberme = driver.findElement(By.cssSelector("label[for='rememberMeCheck']"));
		rememberme.click();
		WebElement button = driver.findElement(By.id("login-btn"));
	    button.click();
	    //Thread.sleep(2000);
	}

	
//	//Click my business 
//	@Test(priority = 4)
//	public void clickmybusiness() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='#/diary/my-businesses']")));
//		click.click();
//	}
	//click history
	@Test(priority = 4)
	public void clickHistory() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='canceled-text canceled-btn font-weight-bold']")));
	    click.click();
	    Thread.sleep(1000);
	}
	//Validate title
	@Test(priority = 4)
	public void title() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	    WebElement titleText = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Meeting History')]")));
		Assert.assertTrue(titleText.isDisplayed(),"Title text is not displayed");
		Assert.assertEquals(titleText.getText(), "Meeting History","Title text is not matched");
	}
	//Validate sub title
	@Test(priority = 5)
	public void subtitle() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	    WebElement subtitleText = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Tuesday, 10 December 2024 at 8:00 AM')]")));
		Assert.assertTrue(subtitleText.isDisplayed(),"Sub title text is not displayed");
	}
	//Close the popup
		@Test(priority = 6)
		public void closePopup() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		    WebElement closePopup = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='close-meeting-history']//i[@class='fa fa-times']")));
            closePopup.click();
		}
		//Validate the history table
		@Test(priority = 7)
		public void table() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-responsive-md mb-4']")));
		    List<WebElement> rows = table.findElements(By.tagName("tr"));
		    boolean isDataFound = false;
	        for (WebElement row : rows) {
// Extract all cells in the current row
	        List<WebElement> cells = row.findElements(By.tagName("td"));

// Check if the desired cell data matches
	         for (WebElement cell : cells) {
	                String cellText = cell.getText();
	                System.out.println("Cell Data: " + cellText); 

//	                if (cellText.equals("ExpectedValue")) {
//	                    isDataFound = true;
//	                    break;
//	                }
	            }

//	            if (isDataFound) {
//	                break;
//	            }
	        }
		}
			
	
}
	
//	@Test
//	public void businesslist() {
//		List<WebElement> rows = driver.findElements(By.xpath("//th[normalize-space()='Business name']"));
//		WebElement nextButton = driver.findElement(By.xpath("//li[@class='pagination-next']"));
//		List<String> allData = new ArrayList<>();
//		for (WebElement row : rows) {
//		    allData.add(row.getText());
//		}
//		boolean hasNextPage = nextButton.isEnabled();
//		nextButton.click();
//		wait.until(ExpectedConditions.stalenessOf(rows.get(0))); // Wait for page to update
//
//		if (!hasNextPage) {
//		    break;
//		}
//      
//		
	
	
	
//	@Test
//    public void testPaginationData() {
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        List<String> allData = new ArrayList<>(); // To store data from all pages
//
//        boolean hasNextPage = true;
//
//        while (hasNextPage) {
//            // Wait for table data to load
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='table-response pb-3']")));
//
//            // Extract data from the current page
//            List<WebElement> rows = driver.findElements(By.xpath("//th[normalize-space()='Business name']"));
//            for (WebElement row : rows) {
//                String rowData = row.getText();
//                allData.add(rowData); // Add row data to the list
//                System.out.println("Row Data: " + rowData);
//            }
//
//            // Check if the "Next" button is enabled
//            WebElement nextButton = driver.findElement(By.xpath("//li[@class='pagination-next']"));
//            hasNextPage = nextButton.isEnabled();
//
//            if (hasNextPage) {
//                nextButton.click(); // Navigate to the next page
//                wait.until(ExpectedConditions.stalenessOf(rows.get(0))); // Wait for the page to update
//            }
//        }
//
//        // Print all data collected
//        System.out.println("Total rows collected: " + allData.size());
//        for (String data : allData) {
//            System.out.println(data);
//        }
//
//        // Validation: Check if the data count matches the expected total
//        int expectedTotal = 23; // Example: Replace with the expected total count
//        assert allData.size() == expectedTotal : "Data count mismatch!";
//    }

	
//	//validate the size of the name list in a page
//	@Test
//	public void sizepagination() {
//		
//	
//	//List<String> namelist = new ArrayList <String>();
//	int sizeOfPagination = driver.findElements(By.xpath("//nav[@aria-label='Pagination']")).size();
//	System.out.println(sizeOfPagination);
//	}
	
	//ul[@class='ngx-pagination']
//	// Loop through the pagination elements and extract text
//	for (WebElement element : paginationElements) {
//	    namelist.add(element.getText().trim()); // Add the text of each element to the list
//	}
//
//	// Print the collected names
//	for (String name : namelist) {
//	    System.out.println(name);
//	}
//
//	// Verify the size of the collected list
//	System.out.println("Total pagination elements: " + namelist.size());
//	
	
//	//Enter a search term(business user name) and check if results are displayed.
//			@Test(priority = 5)
//			public void searchusername()throws InterruptedException {
//		    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//			WebElement searchBox1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
//			Assert.assertTrue(searchBox1.isDisplayed(), "Search box is not displayed");
//			Thread.sleep(500);
//			
//			//Enter a search user name
//			String searchTerm = "Jana";
//		    searchBox1.sendKeys(searchTerm + Keys.ENTER);
//		   // Thread.sleep(1000);
//			}
//
////Validate empty screen
//
//			@Test(priority =6)
//			public void searchresult() {
//				 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//					WebElement searchresult = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='p-2 bd-highlight font-weight-bold']")));	
//		            Assert.assertEquals(searchresult.getText(),"No records found for your search.","Search result is not matched");
//			}
////Clear the search box
//		            
//		      @Test(priority =7)
//			  public void searchBox2() {
//						 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//							WebElement searchBox2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
//		                    searchBox2.clear();
//		    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
//		    pointer.click();
//		   // Thread.sleep(3000);
//		            }
//		      
//		    //Enter a search term(business name) and check if results are displayed.
//				@Test(priority = 8)
//				public void searchbusinessname()throws InterruptedException {
//			    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//				WebElement searchBox3 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
//				Assert.assertTrue(searchBox3.isDisplayed(), "Search box is not displayed");
//				Thread.sleep(500);
//				
//				//Enter a search business name
//				String searchTerm = "Choco bliss";
//			    searchBox3.sendKeys(searchTerm + Keys.ENTER);
//			   // Thread.sleep(1000);
//				}
//
//	//Validate empty screen
//
//				@Test(priority =6)
//				public void searchresult1() throws InterruptedException {
//					
//						
//					 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//						WebElement searchresult1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='p-2 bd-highlight font-weight-bold']")));	
//			            Thread.sleep(1000);
//			            Assert.assertEquals(searchresult1.getText(),"No records found for your search","Search result is not matched");
//			            		}
//	//Clear the search box
//			            
//			      @Test(priority =7)
//				  public void searchBox4() {
//							 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//								WebElement searchBox4 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
//			                    searchBox4.clear();
//			    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
//			    pointer.click();
//			   // Thread.sleep(3000);
//			            }



			

			
			
				

//	//Enter a search term(business owner name) and check if results are displayed.
//		@Test(priority = 5)
//		public void searchusername()throws InterruptedException {
//	    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//		WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));
//		Assert.assertTrue(searchBox.isDisplayed(), "Search box is not displayed");
//		Thread.sleep(500);
//		//Enter a search user name
//		String searchTerm = "Jana";
//	    searchBox.sendKeys(searchTerm + Keys.ENTER);
//	    Thread.sleep(500);
//		 WebElement searchResults = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[normalize-space()='Durkagini']")));
//	     Assert.assertTrue(searchResults.isDisplayed(), "Search results are not displayed");
//	     Assert.assertTrue(searchResults.getText().contains(searchTerm), "Search results do not match the search term");
//	    System.out.println("search date is showed");
//	    searchBox.clear();
//	     WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
//	    pointer.click();
//		}
//		
//		//Enter a search term(business name) and check if results are displayed.
//		@Test(priority = 6)
//		public void searchbusinessname()throws InterruptedException {
//	    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//		WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));
//		Thread.sleep(500);
//		//Enter a search business name
//		String searchTerm = "choco bliss";
//	    searchBox.sendKeys(searchTerm + Keys.ENTER);
//	    Thread.sleep(500);
//	    WebElement searchResults = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@class='tbody-name font-weight-bold']")));
//	    Assert.assertTrue(searchResults.isDisplayed(), "Search results are not displayed");
//	    Assert.assertTrue(searchResults.getText().contains(searchTerm), "Search results do not match the search term");
//	   System.out.println("search date is showed");
//	    searchBox.clear();
////Thread.sleep(1000);
//	    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
//	    pointer.click();
//		}
		


	
//	//Click the sort dropdown 
//	@Test(priority = 5)
//	public void clicksortdropdown() {
//		try {
//			
//		
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//	    WebElement sortdrop = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='ng-arrow-wrapper']")));
//		sortdrop.click();
//	   Thread.sleep(1000);
//	
//		  WebElement option = driver.findElement(By.xpath("//span[normalize-space()='Business name (A to Z)']"));
//          option.click();
//          System.out.println("Successfully selected the sort option: Business name (Z to A)");
//
//    } catch (Exception e) {
//        // Log any exceptions for debugging
//        System.err.println("An error occurred while interacting with the dropdown: " + e.getMessage());
//    }
//
//	
//	}}
      
	    

//        // Initialize the Select class with the dropdown WebElement
//        Select dropdown = new Select(sortdrop);
//
//        // Select an option by visible text
//        dropdown.selectByVisibleText("Business name(A to Z)");
//
//        // Select an option by index (0-based)
//        //dropdown.selectByIndex(2);
	
	
	
	//Table validation for Business name column A to Z
	

	


//	//search button validation
//@Test(priority = 5)
//public void searchbutton() {
//	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	WebElement searchbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));
//	Assert.assertTrue(searchbutton.isDisplayed(),"Button is not displayed");
//	Assert.assertTrue(searchbutton.isEnabled(), "Button is not enabled");
//}
//
////Search button placeholder validation
//@Test(priority = 6)
//public void searchplaceholder() {
//	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	WebElement searchbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));
//	
//// Retrieve the placeholder attribute
//    String placeholderText = searchbutton.getAttribute("placeholder");
//// Expected placeholder text
//    String expectedPlaceholder = "Search";
//// Validate the placeholder
//    if (placeholderText.equals(expectedPlaceholder)) {
//        System.out.println("Search placeholder text is correct: " + placeholderText);
//    } else {
//        System.out.println("Placeholder text is incorrect. Found: " + placeholderText);
//    }
//} 
////sort button validation
//@Test(priority = 7)
//public void sortbutton() {
//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//WebElement searchbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@aria-autocomplete='list']")));
//Assert.assertTrue(searchbutton.isDisplayed(),"Button is not displayed");
//Assert.assertTrue(searchbutton.isEnabled(), "Button is not enabled");
//}
//
//     
//@Test(priority = 8)
//public void sortplaceholder() {
//	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	WebElement sortbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@aria-autocomplete='list']")));
//	
//// Retrieve the placeholder attribute
//    String placeholderText = sortbutton.getAttribute("placeholder");
//// Expected placeholder text
//    String expectedPlaceholder = "Sort by:Recently allocated";
//// Validate the placeholder
//    if (placeholderText.equals(expectedPlaceholder)) {
//        System.out.println("Sort placeholder text is correct: " + placeholderText);
//    } else {
//        System.out.println("Sort placeholder text is incorrect. Found: " + placeholderText);
//    }
//} 
//
//	
//
//    //Business count button
//@Test(priority = 9)
//public void businessess() {
//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//WebElement count = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='font-weight-bold text-muted py-2 px-3']")));
//Assert.assertTrue(count.isDisplayed(),"Button is not displayed");
//Assert.assertTrue(count.isEnabled(), "Button is not enabled");
//Assert.assertEquals(count.getText(), "23 businesses", "Text is not matched");
//}	
//
////Table validation
//
////Locate the table
//
//		@Test(priority = 10)
//		public void table() {
//			try {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//		    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-response pb-3']")));
//			
//// Extract all rows of the table
//	        List<WebElement> rows = table.findElements(By.tagName("tr"));
//
//// Loop through rows to find the required data
//	        boolean isDataFound = false;
//	        for (WebElement row : rows) {
//// Extract all cells in the current row
//	        List<WebElement> cells = row.findElements(By.tagName("td"));
//
//// Check if the desired cell data matches
//	         for (WebElement cell : cells) {
//	                String cellText = cell.getText();
//	                System.out.println("Cell Data: " + cellText); 
//
//	                if (cellText.equals("ExpectedValue")) {
//	                    isDataFound = true;
//	                    break;
//	                }
//	            }
//
//	            if (isDataFound) {
//	                break;
//	            }
//	        }
//
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	    }}
//		
//}
//	//Click submission records 
//	@Test(priority = 4)
//	public void clicksubmission() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.id("submission-record")));
//		click.click();
//	}
//	
//
//	//Enter a search term(business user name) and check if results are displayed.
//	@Test(priority = 5)
//	public void searchusername()throws InterruptedException {
//    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//	WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
//	Assert.assertTrue(searchBox.isDisplayed(), "Search box is not displayed");
//	Thread.sleep(500);
//	
//	//Enter a search user name
//	String searchTerm = "Thulasi";
//    searchBox.sendKeys(searchTerm + Keys.ENTER);
//   // Thread.sleep(1000);
//
//    searchBox.clear();
//    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
//    pointer.click();
//   // Thread.sleep(3000);
//	}
//
//	//Enter a search term(business name) and check if results are displayed.
//	@Test(priority = 6)
//	public void searchbusinessname()throws InterruptedException {
//    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
//	WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
//	Thread.sleep(500);
//	
//	//Enter a search business name
//	String searchTerm = "Teen fashion";
//    searchBox.sendKeys(searchTerm + Keys.ENTER);
//    Thread.sleep(1000);
//
//    searchBox.clear();
//    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
//    pointer.click();
//    Thread.sleep(1000);
//	}


//	//Click calendar and select a date
//	@Test(priority = 5)
//	public void clickcalendar(){
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//	    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".input-group-text.bg-white")));
//		click.click();
//		//Thread.sleep(3000);
//		
//		Assert.assertTrue(click.isDisplayed(), "Button is not displayed on the page");
//		Assert.assertTrue(click.isEnabled(), "Button is not enabled");
//		
//	}
//	
//	@Test(priority = 6)
//	public void selectadate()throws InterruptedException {
//		try {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement dateselection = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[aria-label='Sunday, December 8, 2024'] span[class='custom-day']")));
//		//dateselection.click();
//	  System.out.println("Date element is clickable");
//	  
//			 // div[aria-label='Saturday, December 7, 2024'] span[class='custom-day']
//        Actions actions = new Actions(driver);
//        actions.doubleClick(dateselection).perform();
//        System.out.println("Double-click action performed");
//        Thread.sleep(2000);
//        
//	}  catch (Exception e) {
//        System.out.println("Error: " + e.getMessage());
//        e.printStackTrace(); 
//
//
//}
//}}
//	//Locate the table
//	
//	@Test(priority = 8)
//	public void table() {
//		try {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-response pb-3']")));
//		
//	
//	    // Extract all rows of the table
//        List<WebElement> rows = table.findElements(By.tagName("tr"));
//
//        // Loop through rows to find the required data
//        boolean isDataFound = false;
//        for (WebElement row : rows) {
//            // Extract all cells in the current row
//            List<WebElement> cells = row.findElements(By.tagName("td"));
//
//            // Check if the desired cell data matches
//            for (WebElement cell : cells) {
//                String cellText = cell.getText();
//                System.out.println("Cell Data: " + cellText); 
//
//                if (cellText.equals("ExpectedValue")) {
//                    isDataFound = true;
//                    break;
//                }
//            }
//
//            if (isDataFound) {
//                break;
//            }
//        }
//
//        // Assert that the data is found
//        Assert.assertTrue(isDataFound, "The expected data was not found in the table.");
//
//    } catch (Exception e) {
//        e.printStackTrace();
//    }}}
//	

	
//	//Click the status filter option
//	@Test(priority = 7)
//	public void clickstatusfilter() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement status = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='ng-arrow-wrapper']")));
//		status.click();
//	}
//	
//	//Click the appointment not scheduled option
//	@Test(priority = 8)
//	public void clickappointment() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement appointmentstatus = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Appointment not scheduled']")));
//		appointmentstatus.click();
//	}
//	
//	
//	//Validate the table
//	@Test(priority = 9)
//	public void column1() {
//	List<WebElement> columns=driver.findElements(By.tagName("th"));
//	int columnCount = columns.size();
//	System.out.println("Number of columns" + columnCount);
//	}
//	
//	@Test(priority = 10)
//	public void row() {
//	List<WebElement> columns=driver.findElements(By.tagName("tr"));
//	int columnCount = columns.size();
//	System.out.println("Number of columns" + columnCount);
//	}
//	
//	
//	//Locate the table
//	
//	@Test(priority = 8)
//	public void table() {
//		try {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-response pb-3']")));
//		
//	
//	    // Extract all rows of the table
//        List<WebElement> rows = table.findElements(By.tagName("tr"));
//
//        // Loop through rows to find the required data
//        boolean isDataFound = false;
//        for (WebElement row : rows) {
//            // Extract all cells in the current row
//            List<WebElement> cells = row.findElements(By.tagName("td"));
//
//            // Check if the desired cell data matches
//            for (WebElement cell : cells) {
//                String cellText = cell.getText();
//                System.out.println("Cell Data: " + cellText); 
//
//                if (cellText.equals("ExpectedValue")) {
//                    isDataFound = true;
//                    break;
//                }
//            }
//
//            if (isDataFound) {
//                break;
//            }
//        }
//
//        // Assert that the data is found
//        Assert.assertTrue(isDataFound, "The expected data was not found in the table.");
//
//    } catch (Exception e) {
//        e.printStackTrace();
//    }}}
//	

//	
//	//Click create
//	 @Test(priority = 4)
//	 public void create() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//		    WebElement create = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='p-label-small']")));
//			create.click(); 
//	 }
//	 //Select a date
//	 @Test(priority = 5)
//	 public void date() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//		    WebElement date = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='btn-light bg-primary text-white']")));
//			date.click(); 
//	 }
//	 
//	 
//	 //select a time slot
//	 @Test(priority = 6)
//	 public void timeslot() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//		    WebElement time = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='8:00 am']")));
//			time.click(); 
//	 }
//	 //Click add appointment
//	 @Test(priority = 7)
//	 public void add() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//		    WebElement appointment = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add appointment']")));
//			appointment.click(); 
//	 }
//	 //Click Okay on the pop up
//	 @Test(priority = 7)
//	 public void okay() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//		    WebElement okay = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Okay']")));
//			okay.click(); 
//	 }
//}
//	//Click submission records 
//	@Test(priority = 4)
//	public void clicksubmission() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.id("submission-record")));
//		click.click();
//	}
//	//Validate calendar button
//	@Test(priority = 5)
//	public void calendar() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement calendar = wait.until(ExpectedConditions.elementToBeClickable(By.id("inputDate-sizing-lg")));	
//		Assert.assertTrue(calendar.isDisplayed(), "Button is not displayed");
//		Assert.assertTrue(calendar.isEnabled(), "Button is not enabled");
//		//Assert.assertEquals(calendar.getText(), "06/12/2024", "Button text does not match");
//	}
//	//Validate search button
//	@Test(priority = 6)
//	public void search() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement search = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));	
//		Assert.assertTrue(search.isDisplayed(), "Button is not displayed");
//		Assert.assertTrue(search.isEnabled(), "Button is not enabled");
//		Assert.assertEquals(search.getText(), "Search", "Button text does not match");
//	}
//	
//	//Validate the status button
//	@Test(priority = 7)
//	public void status() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	    WebElement status = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@aria-autocomplete='list']")));	
//		Assert.assertTrue(status.isDisplayed(), "Button is not displayed");
//		Assert.assertTrue(status.isEnabled(), "Button is not enabled");
//		Assert.assertEquals(status.getText(), "Search", "Button text does not match");
//	}
//	
//	//Validate the table
//	@Test
//	public void column1() {
//	List<WebElement> columns=driver.findElements(By.tagName("th"));
//	int columnCount = columns.size();
//	System.out.println("Number of columns" + columnCount);
//	}
//	
//	@Test
//	public void row() {
//	List<WebElement> columns=driver.findElements(By.tagName("tr"));
//	int columnCount = columns.size();
//	System.out.println("Number of columns" + columnCount);
//	}
//	
//	}
//	    @Test(priority = 4)		
//		public void clickprofile() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement profile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Profile']")));
//	       profile.click();
//	    }	
//		
//		@Test(priority = 5)
//		public void imageupload()  throws InterruptedException {
//			try {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-camera']")));
//	       image.click();
//		
//		String file="C:\\Users\\aksaj\\OneDrive\\football-730418_1280.jpg";
//		StringSelection selection = new StringSelection(file);
//
//	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
//		
//	    Thread.sleep(1000);
//	   Robot robot = new Robot();
//	   robot.keyPress(KeyEvent.VK_CONTROL);
//	   robot.keyPress(KeyEvent.VK_V);
//	   robot.keyRelease(KeyEvent.VK_V);
//	   robot.keyRelease(KeyEvent.VK_CONTROL);
//	   Thread.sleep(1000);
//	   robot.keyPress(KeyEvent.VK_ENTER);
//	   robot.keyRelease(KeyEvent.VK_ENTER);
//	   
//	   
//		  } catch (AWTException e) {
//	            System.out.println("AWTException occurred: " + e.getMessage());
//		            e.printStackTrace(); 
//	
//
//			}}
//		//Again upload a image
//		@Test(priority = 6)
//		public void imageupload1()  throws InterruptedException {
//			try {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[@for='file-upload1']")));
//	       image.click();
//		
//		
//			
//		String file2="C:\\Users\\aksaj\\OneDrive\\macarons-1850216_1280.jpg";
//		StringSelection selection = new StringSelection(file2);
//
//	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
//		
//	    Thread.sleep(1000);
//	   Robot robot = new Robot();
//	   robot.keyPress(KeyEvent.VK_CONTROL);
//	   robot.keyPress(KeyEvent.VK_V);
//	   robot.keyRelease(KeyEvent.VK_V);
//	   robot.keyRelease(KeyEvent.VK_CONTROL);
//	   Thread.sleep(2000);
//	   robot.keyPress(KeyEvent.VK_ENTER);
//	   robot.keyRelease(KeyEvent.VK_ENTER);
//	   
//	   
//		  } catch (AWTException e) {
//	            System.out.println("AWTException occurred: " + e.getMessage());
//		            e.printStackTrace(); 
//	
//
//			}}
//	      //click confirm
//				@Test(priority = 11)
//				public void clickconfirm() {
//					WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//			        WebElement confirm = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Confirm']")));
//			        confirm.click();
//				}  
//				//click save
//			        @Test(priority = 12)
//			        public void savechanges() {
//			        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//			        WebElement save = wait.until(ExpectedConditions.elementToBeClickable(By.id("save-changes")));
//			       save.click();     
//				}
//		      
		        
			

		
		
		//close the image upload pop up
//		   @Test(priority = 6)
//	        public void close() {
//	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement close = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='close-imageCropperModel']//i[@class='fa fa-times']")));
//	        close.click(); 
//		   }}

//		//Click crop
//	        @Test(priority = 6)
//	        public void clickcrop() {
//	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	        WebElement crop = wait.until(ExpectedConditions.elementToBeClickable(By.id("croped-id-btn")));
//	        crop.click();  
//	        System.out.println("Crop button clicked successfully.");
//	        }
//	        
//	      //Click image ratio buttons
//	        @Test(priority = 7)
//	        public void clickratio1() {
//	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	        WebElement ratio1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("imageRatio2")));
//	        ratio1.click(); 
//	        }
//	        
//	        @Test(priority = 8)
//	        public void clickratio2() {
//	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	        WebElement ratio2 = wait.until(ExpectedConditions.elementToBeClickable(By.id("imageRatio3")));
//	        ratio2.click(); 
//	        } 
//	        
//	      //Click rotate
//	        
//	        @Test(priority = 9)
//	        public void clickrotate() {
//	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	        WebElement rotate = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='rotate-btn']")));
//	        rotate.click(); 
//	        } 
//	        
//	        //click save
//	        @Test(priority = 10)
//	        public void clicksave() {
//	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//	        WebElement savechanges = wait.until(ExpectedConditions.elementToBeClickable(By.id("save-btn-changes")));
//	        savechanges.click(); 
//	        } 


		
//	       // Click cancel 
//	      @Test(priority = 10)
//	      public void clickcancel() {
//		        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
//		        WebElement cancel = wait.until(ExpectedConditions.elementToBeClickable(By.id("cancel-btn-changes")));
//		        cancel.click();     
//			}
	
//	@Test(priority = 4)
//	public void addtimeslot() {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='p-label-small'][normalize-space()='Add timeslot']")));
//		button.click();	
//}
//	@Test(priority = 5)
//	public void title() {
//	WebElement title = driver.findElement(By.cssSelector("div[class='col-sm-12 col-md-12 col-lg-6 col-12 manage-availability-view add-availability'] span[class='title font-weight-bold']"));
//	Assert.assertTrue(title.isDisplayed(), "Title is not displayed on the popup");
//	Assert.assertEquals(title.getText(), "Add Availability");
//	
//	}
//    @Test(priority = 6)
//    public void date() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement date = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='input-group-text bg-white']//*[name()='svg']//*[name()='path' and contains(@d,'M2.5 4a.5.')]")));
//        date.click();
//    }
//    @Test(priority = 7)
//    public void customeday() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement customday = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[aria-label='Saturday, November 30, 2024'] span[class='custom-day']")));
//        customday.click();     
//}
//    @Test(priority = 8)
//    public void selecttime() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement select = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='12:30 AM'] ")));
//        select.click();  
//    }
//    
//    @Test(priority = 9)
//    public void clicktime() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement clicktime = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='input-group-append']//span[@class='input-group-text p-border-radius-right bg-white']//*[name()='svg']")));
//        clicktime.click();  
//    }
//    @Test(priority = 10)
//    public void endtime() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement end = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='inputEndTime-sizing-lg'] ")));
//        end.click(); 
//    }
//    
//    @Test(priority = 11)
//    public void duration() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement durationvalidation = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Duration 30 minutes')] ")));
//        durationvalidation.click(); 
//    }
//    
//    
//    @Test(priority = 12)
//    public void button() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement addbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='row mt-3 mb-5'] button[class='btn p-button m-p-button w-100']")));
//        addbutton.click(); 
//    }	
//    
//    @Test(priority = 13)
//    public void delete() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement delete = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@data-target='#cancel-schedule']//*[name()='svg']")));
//        delete.click();	
//    }
//    
//    @Test(priority = 14)
//    public void deleteavailable() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement yesbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn p-light-button btn-block m-p-button']")));
//        yesbutton.click();
//    }
    
    
//	@Test(priority = 4) 
//public void logouta() {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
//		WebElement logoutfield = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-drop ")));
//        logoutfield.click(); 
//	}
//	
//	@Test(priority = 5)
//	public void logout() {
//		
//		
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
//		WebElement logout= wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("logout")));
//        logout.click(); 
//		
//
//	}
	
//	//Try to copy the invalid time slot
//	@Test(priority = 4)
//	public void manage() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement manage = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[class='btn p-light-button'] span[class='p-label-small']")));
//        manage.click();
//	}
//	@Test(priority = 5)
//	public void copy() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement copy = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Copy availability']")));
//        copy.click();
//	}
//	@Test(priority = 6)
//	public void copytimeslot() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement copyb = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row my-5']//button[@class='btn p-button m-p-button w-100']")));
//        copyb.click();
//	}
//	@Test(priority = 7)
//	public void clickokay() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement okayb = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn p-button w-100 m-p-button']")));
//        okayb.click();
//	}
//	
//	//Copy the correct time slot
//	//Click date to copy from
//	@Test
//	public void copyfrom() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement datec = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row input-margin-bottom']//div[@class='col-sm-8']//span[@class='input-group-text p-border-radius-right bg-white']//*[name()='svg']//*[name()='path' and contains(@d,'M2.5 4a.5.')]")));
//        datec.click();
//	}
//	//Select a future date
//	@Test
//	public void selectdate() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement selectd = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='custom-day selected']")));
//        selectd.click();
//	}
//   //Click the date to copy to
//	@Test
//	public void copyto() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement copyto = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row']//span[@class='input-group-text p-border-radius-right bg-white']")));
//        copyto.click();
//	}
//   //Select a available day
//	@Test
//	public void selectdate2() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement availabled = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='custom-day'][normalize-space()='30']")));
//        availabled.click();
//	}
//	//Click the copy time slot button
//	@Test
//	public void copytime() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement copyt = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row my-5']//button[@class='btn p-button m-p-button w-100']")));
//        copyt.click();
//	}
//	@Test
//	public void icon() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement icon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[8]//span[1]//div[1]//div[1]//div[1]//span[2]//span[1]//*[name()='svg']")));
//        icon.click();
//	}
//	//click the copy timeslot button
//	public void copytime() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
//        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Copy timeslots']")));
//        button.click();
//	}
	
	
	
	//Click the cancel the appointment and close without cancel it
	
	//Click cancel button
//	@Test(priority = 1)
//	public void clickcancel1() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='c-point ng-star-inserted']//*[name()='svg']//*[name()='path' and contains(@d,'M16 8A8 8 ')]")));
//        button1.click();
//    }
//	//Click close button on the popup
//	@Test(priority = 2)
//	public void clickclose1() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='close-cancel-schedule']//i[@class='fa fa-times']")));
//        button1.click();
//    }
//	
//	//Cancel the appointment
//	//Click cancel button
//		@Test(priority = 3)
//		public void clickcancel2() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='c-point ng-star-inserted']//*[name()='svg']//*[name()='path' and contains(@d,'M16 8A8 8 ')]")));
//	        button1.click();
//	    }
//		//Enter a reason for cancellation
//		@Test(priority = 4)
//		public void reason() {
//			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement reason = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@type='text']")));
//	        reason.sendKeys("Time");
//	    }
//		
//		//Click yes button on the popup
//				@Test(priority = 5)
//				public void clickyes() {
//					WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//			        WebElement yes = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn p-light-button btn-block m-p-button']")));
//			        yes.click();
//			    }
	
	//driver.finElement(By.id("btn-user-image-modal-open")).sendKeys("C:\\Users\\aksaj\\OneDrive\\Desktop\\Durka\\Downloaded Images\\ao-dai-6152101_1920.jpg");
	
//	
//    @Test(priority = 6)
//    public void testImageUpload() {
//        // Locate the file input element
//       // WebElement fileInput = driver.findElement(By.xpath("//input[@type='file']"));
//
//        // Provide the full path of the image to upload
//        String filepath = "C:\\Users\\aksaj\\OneDrive\\Desktop\\Durka\\Downloaded Images\\ao-dai-6152101_1920.jpg"; // Replace with the actual file path
//        image.sendKeys(filepath);

//        // Optionally, click the upload button (if required)
//        WebElement uploadButton = driver.findElement(By.id("uploadButton")); // Replace with actual locator
//        uploadButton.click();
//
//        // Add verification to ensure the file was uploaded successfully
//        WebElement successMessage = driver.findElement(By.id("successMessage")); // Replace with actual locator
//        assert successMessage.isDisplayed() : "Image upload failed!";
    
		
	
	//file_input = driver.find_element(By.XPATH, '//input[@type="file"]')
//@Test(priority = 5)
//public void validateProfileDetails() {
//    // Expected values
//    String expectedfirstName = "Aksaja";
//    String expectedlastName = "Thuriga";
//    String expectedEmail = "aksaja50@gmail.com";
//    String expectedLocation1 = "Bolton",expectedLocation2 = "Bristol";

    // Locate and extract profile details
//    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//    WebElement firstnameElement = wait.until(ExpectedConditions.elementToBeClickable(By.id("first-name")));
//    //WebElement firstnameElement = driver.findElement(By.id("first-name")); // Replace with actual locator
//    WebElement lastnameElement = driver.findElement(By.id("last-name"));
//    WebElement emailElement = driver.findElement(By.id("sales-partner-email")); // Replace with actual locator
//    WebElement locationElement = driver.findElement(By.xpath("//div[@class='border rounded disable-location p-bg-light d-flex align-items-center p-border-radios m-rad-8']")); // Replace with actual locator
//
//    String actualfirstName = firstnameElement.getText();
//    String actuallastName = lastnameElement.getText();
//    String actualEmail = emailElement.getText();
//    String actualLocations = locationElement.getText();
//
//    // Validate each detail
//    Assert.assertEquals(actualfirstName, expectedfirstName, "Name does not match!");
//    Assert.assertEquals(actuallastName, expectedlastName, "Name does not match!");
//    Assert.assertEquals(actualEmail, expectedEmail, "Email does not match!");
//    Assert.assertTrue(actualLocations.equals(expectedLocation1) || actualLocations.equals(expectedLocation2), "Location does not match!");
//    System.out.println("Actual value: " + actualfirstName);
    
//    lastnameElement someObject = new lastnameElement();
//    someObject.setName("Thuriga"); // Ensure the name is set
//    String actualName = someObject.getName();
//    Assert.assertEquals("Name does not match!", "Thuriga", actualName);




