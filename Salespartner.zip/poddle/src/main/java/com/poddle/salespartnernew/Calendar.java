package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Calendar extends setup {

	//click the next week view in the calendar
	@Test
	public void arrowicon() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement icon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[name()='path' and contains(@d,'M382.678 2')]")));
        icon.click();
}
	@Test
	public void calendar() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement icon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id='calendar-date']//*[name()='svg']")));
        icon.click();
}
	@Test
	public void selectday() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement dayS = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'30')]")));
        dayS.click();
}
}
