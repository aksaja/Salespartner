package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class calendarview extends setup{
	//Calendar view validation
	
	//Validate the title
	@Test
	public void title() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement title = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='p-page-heading']")));
        Assert.assertEquals(title.getText(),"Diary","Text doest not match");
        }
	
	//validate the body text
	@Test
	public void bodytext() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement body = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
        Assert.assertEquals(body.getText(),"Manage your availability and sales meetings.","Text doest not match");
	}
	//Validate the available time slots

	
	//upcoming text present
	
	//span[@class='font-weight-bold p-label-medium']
	
	
	//Validate the manage availability button - displayed, clickable
	@Test
	public void managebutton() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement manage = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Manage availability']")));
        Assert.assertEquals(manage.getText(),"Manage availability","Text doest not match");
        Assert.assertTrue(manage.isDisplayed(), "Button is not displayed on the page");
		Assert.assertTrue(manage.isEnabled(), "Button is not enabled");
	}
	//Calendar buttons
	@Test
	public void calendarbutton() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement calendar = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[name()='path' and contains(@d,'M117.979 2')]")));
        Assert.assertTrue(calendar.isDisplayed(), "Button is not displayed on the page");
		Assert.assertTrue(calendar.isEnabled(), "Button is not enabled");
	}
	
	//Available button and scheduled button validation
	@Test
	public void availablebutton() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement available = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='Saturday-2024-11-30-130']//span[@class='font-weight-bold'][normalize-space()='Available']")));
        Assert.assertTrue(available.isDisplayed(), "Button is not displayed on the page");
		Assert.assertTrue(available.isEnabled(), "Button is not enabled");
	}
	
	
	//scheduled button 
	@Test
	public void schedulebutton() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement scheduled = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='mt-1 c-point text-truncate'][normalize-space()='Durkagini']")));
        Assert.assertTrue(scheduled.isDisplayed(), "Button is not displayed on the page");
		Assert.assertTrue(scheduled.isEnabled(), "Button is not enabled");
	}
	
	//copy icon validation
	@Test
	public void copybutton() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement copy = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//copy button - //div[7]//span[1]//div[1]//div[1]//div[1]//span[2]//span[1]//*[name()='svg']")));
        Assert.assertTrue(copy.isDisplayed(), "Button is not displayed on the page");
		Assert.assertTrue(copy.isEnabled(), "Button is not enabled");
	}
	
	
	
	}
	
	
	
	
	
	

	
	
	
	

	


