package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class searchforvalid extends setup{
	

	//Enter a search term(business user name) and check if results are displayed.
	@Test(priority = 5)
	public void searchusername()throws InterruptedException {
    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
	WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
	Assert.assertTrue(searchBox.isDisplayed(), "Search box is not displayed");
	Thread.sleep(500);
	//Enter a search user name
	String searchTerm = "Durkagini";
    searchBox.sendKeys(searchTerm + Keys.ENTER);
    Thread.sleep(500);
	 WebElement searchResults = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[normalize-space()='Durkagini']")));
     Assert.assertTrue(searchResults.isDisplayed(), "Search results are not displayed");
     Assert.assertTrue(searchResults.getText().contains(searchTerm), "Search results do not match the search term");
    System.out.println("search date is showed");
    searchBox.clear();
     WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
    pointer.click();
	}
	
	//Enter a search term(business name) and check if results are displayed.
	@Test(priority = 6)
	public void searchbusinessname()throws InterruptedException {
    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
	WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
	Thread.sleep(500);
	//Enter a search business name
	String searchTerm = "Mikura jewellery";
    searchBox.sendKeys(searchTerm + Keys.ENTER);
    Thread.sleep(500);
    WebElement searchResults = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[normalize-space()='Mikura jewellery']")));
    Assert.assertTrue(searchResults.isDisplayed(), "Search results are not displayed");
    Assert.assertTrue(searchResults.getText().contains(searchTerm), "Search results do not match the search term");
   System.out.println("search date is showed");
    searchBox.clear();

    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
    pointer.click();
	}
	}