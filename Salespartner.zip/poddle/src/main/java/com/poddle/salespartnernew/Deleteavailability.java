package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Deleteavailability extends setup{
//Delete the availability
	 @Test(priority = 13)
	    public void delete() {
	    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
			WebElement delete = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@data-target='#cancel-schedule']//*[name()='svg']")));
	        delete.click();	
	    }
	    
	    @Test(priority = 14)
	    public void deleteavailable() {
	    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
			WebElement yesbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn p-light-button btn-block m-p-button']")));
	        yesbutton.click();
	    }
//close the delete availability popup without delete
	    //click the cancel
	    @Test(priority = 13)
	    public void cancel() {
	    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
			WebElement cancel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='c-point ng-star-inserted']//*[name()='svg']")));
	        cancel.click();	
	    } 
//click close icon on the popup
	    @Test(priority = 13)
	    public void closeicon() {
	    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
			WebElement close = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='close-cancel-schedule']//i[@class='fa fa-times']")));
	        close.click();	
	  
}}
