package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Logout extends setup{
	@Test(priority = 18) 
public void logouta() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement logoutfield = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-drop ")));
        logoutfield.click(); 
	}
	
	@Test
	public void logout() {
		
		
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement logout= wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("logout")));
        logout.click(); 
		

	}

	

}
