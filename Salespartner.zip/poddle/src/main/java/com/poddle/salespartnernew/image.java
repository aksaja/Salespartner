package com.poddle.salespartnernew;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class image extends setup {
	
//	//Click the profile
//	@Test(priority = 1)		
//	public void clickprofile() {
//	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//        WebElement profile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Profile']")));
//       profile.click();
//    }	
	
	//Click the image upload
	@Test(priority = 1)
	public void imageupload()  throws InterruptedException {
		try {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-camera']")));
       image.click();
	
	 
		
	String file="C:\\Users\\aksaj\\OneDrive\\football-730418_1280.jpg";
	StringSelection selection = new StringSelection(file);

    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
  Thread.sleep(500);
   Robot robot = new Robot();
   robot.keyPress(KeyEvent.VK_CONTROL);
   robot.keyPress(KeyEvent.VK_V);
   robot.keyRelease(KeyEvent.VK_V);
   robot.keyRelease(KeyEvent.VK_CONTROL);
   Thread.sleep(500);
   robot.keyPress(KeyEvent.VK_ENTER);
   robot.keyRelease(KeyEvent.VK_ENTER);
   
		  } catch (AWTException e) {
	            //System.out.println("AWTException occurred: " + e.getMessage());
	            e.printStackTrace(); 
	

		}}
	 //click confirm
	@Test(priority = 2)
	public void clickconfirm() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
        WebElement confirm = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Confirm']")));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("button[id='upload-btn'] span[class='p-label-small']"))); // Adjust this selector
        confirm.click();
	}   
	//click save
        @Test(priority = 3)
        public void savechanges() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
        WebElement save = wait.until(ExpectedConditions.elementToBeClickable(By.id("save-changes")));
        save.click();
        
	}
	}