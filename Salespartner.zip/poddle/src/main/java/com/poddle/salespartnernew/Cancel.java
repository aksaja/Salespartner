package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Cancel extends setup {

	
	//Click the cancel the appointment and close without cancel it
	
	//Click cancel button
	@Test
	public void clickcancel1() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='c-point ng-star-inserted']//*[name()='svg']//*[name()='path' and contains(@d,'M16 8A8 8 ')]")));
        button1.click();
    }
	//Click close button on the popup
	@Test
	public void clickclose1() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='close-cancel-schedule']//i[@class='fa fa-times']")));
        button1.click();
    }
	
	//Cancel the appointment
	//Click cancel button
		@Test
		public void clickcancel2() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='c-point ng-star-inserted']//*[name()='svg']//*[name()='path' and contains(@d,'M16 8A8 8 ')]")));
	        button1.click();
	    }
		//Enter a reason for cancellation
		@Test
		public void reason() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement reason = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@type='text']")));
	        reason.sendKeys("Time");
	    }
		
		//Click yes button on the popup
				@Test
				public void clickyes() {
					WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
			        WebElement yes = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn p-light-button btn-block m-p-button']")));
			        yes.click();
			    }
}
