package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class searchinmybusinessforinvalid extends setup{

	//Enter a search term(business user name) and check if results are displayed.
	@Test(priority = 5)
	public void searchusername()throws InterruptedException {
    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
	WebElement searchBox1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
	Assert.assertTrue(searchBox1.isDisplayed(), "Search box is not displayed");
	Thread.sleep(500);
	
	//Enter a search user name
	String searchTerm = "Jana";
    searchBox1.sendKeys(searchTerm + Keys.ENTER);
   // Thread.sleep(1000);
	}

//Validate empty screen

	@Test(priority =6)
	public void searchresult() {
		 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
			WebElement searchresult = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='p-2 bd-highlight font-weight-bold']")));	
            Assert.assertEquals(searchresult.getText(),"No records found for your search.","Search result is not matched");
	}
//Clear the search box
            
      @Test(priority =7)
	  public void searchBox2() {
				 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
					WebElement searchBox2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
                    searchBox2.clear();
    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
    pointer.click();
   // Thread.sleep(3000);
            }
      
    //Enter a search term(business name) and check if results are displayed.
		@Test(priority = 8)
		public void searchbusinessname()throws InterruptedException {
	    WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement searchBox3 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
		Assert.assertTrue(searchBox3.isDisplayed(), "Search box is not displayed");
		Thread.sleep(500);
		
		//Enter a search business name
		String searchTerm = "Choco bliss";
	    searchBox3.sendKeys(searchTerm + Keys.ENTER);
	   // Thread.sleep(1000);
		}

//Validate empty screen

		@Test(priority =6)
		public void searchresult1() throws InterruptedException {
			
				
			 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
				WebElement searchresult1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='p-2 bd-highlight font-weight-bold']")));	
	            Thread.sleep(1000);
	            Assert.assertEquals(searchresult1.getText(),"No records found for your search","Search result is not matched");
	            		}
//Clear the search box
	            
	      @Test(priority =7)
		  public void searchBox4() {
					 WebDriverWait wait  = new WebDriverWait(driver,Duration.ofSeconds(10));
						WebElement searchBox4 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
	                    searchBox4.clear();
	    WebElement pointer = driver.findElement(By.xpath("//i[@class='fa fa-close text-primary pointer']"));
	    pointer.click();
	   // Thread.sleep(3000);
	            }

}
