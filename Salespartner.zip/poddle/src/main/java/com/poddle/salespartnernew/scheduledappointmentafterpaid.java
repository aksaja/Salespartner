package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class scheduledappointmentafterpaid extends setup{
	
	//Click back arrow on the calendar view
	@Test
	public void clickb1() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[name()='path' and contains(@d,'M198.608 2')]")));
        button1.click();
        }
	
	@Test
	public void clickb2() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement button2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//body/app-root/div[@class='wrapper']/div[@class='content-wrapper']/app-schedule-calendar[@class='ng-star-inserted']/section[@id='content']/div[@class='component-content']/div[@class='row']/div[@class='col-lg-11 mx-auto']/div[@class='ng-star-inserted']/div[@class='ng-star-inserted']/div[@class='row border-bottom border-4 mb-4 pt-3 sticky-top calander-top']/div[@class='col-12 d-flex justify-content-center mb-4']/span[1]//*[name()='svg']")));
        button2.click();
        }
	

	//Click the scheduled appointment
		@Test
		public void viewappointment() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='tharusan']")));
	        button1.click();

}
	//Validate the payment after paid
		@Test
		public void payment() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	        WebElement paybutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='badge rounded-pill bg-success py-2 pill-paid']")));
	        Assert.assertEquals(paybutton.getText(),"Paid","Text doest not match");

		}	
}
