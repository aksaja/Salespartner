package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class copyavailabilityC extends setup{

	//Copy availability via calendar view
	// Click the copy availability icon
	@Test
	public void icon() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement icon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[8]//span[1]//div[1]//div[1]//div[1]//span[2]//span[1]//*[name()='svg']")));
        icon.click();
	}
	//click the copy timeslot button
	public void copytime() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Copy timeslots']")));
        button.click();
	}
	//Try to copy the invalid
	//Click the copy availability icon
	@Test
	public void icon1() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement icon1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[7]//span[1]//div[1]//div[1]//div[1]//span[2]//span[1]//*[name()='svg']")));
        icon1.click();
	}
	//click the copy timeslot button
        public void copytimeb() {
    		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
            WebElement button1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='row my-5']//button[@class='btn p-button m-p-button w-100']")));
            button1.click();
        }
	//Click okay in the popup
        @Test
    	public void okayb() {
    		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
            WebElement okayb = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn p-button w-100 m-p-button']")));
            okayb.click();
    	}  
        
	}


