package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Forgetpassword extends setup {
	 @Test
	 public void browse() {
	 driver.get("https://www.google.com");
	 driver.get("https://sales-partner.poddleuat.demotown.co.uk/#/diary/calendar");
	 }
	@Test(priority = 1)
	public void signin1(){
		
		 WebElement emailField = driver.findElement(By.id("login-email"));
		 emailField.sendKeys("aksaja5@gmail.com");
		 WebElement forgotpassword = driver.findElement(By.id("forgot-pwd"));
		 forgotpassword.click();
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 WebElement forgetemail= wait.until(ExpectedConditions.elementToBeClickable(By.id("forgot-email")));
		 forgetemail.sendKeys("aksaja50@gmail.com");
		 WebElement continuebutton = wait.until(ExpectedConditions.elementToBeClickable(By.id("continue-btn")));
		 continuebutton.click();
		
	}
	
	

}
