package com.poddle.salespartnernew;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class validatemybusiness extends setup{

	
	//Click my business 
	@Test(priority = 4)
	public void clickmybusiness() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='#/diary/my-businesses']")));
		click.click();
	}
	
	//search button validation
@Test(priority = 5)
public void searchbutton() {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	WebElement searchbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));
	Assert.assertTrue(searchbutton.isDisplayed(),"Button is not displayed");
	Assert.assertTrue(searchbutton.isEnabled(), "Button is not enabled");
}

//Search button placeholder validation
@Test(priority = 6)
public void searchplaceholder() {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	WebElement searchbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search']")));
	
// Retrieve the placeholder attribute
    String placeholderText = searchbutton.getAttribute("placeholder");
// Expected placeholder text
    String expectedPlaceholder = "Search";
// Validate the placeholder
    if (placeholderText.equals(expectedPlaceholder)) {
        System.out.println("Search placeholder text is correct: " + placeholderText);
    } else {
        System.out.println("Placeholder text is incorrect. Found: " + placeholderText);
    }
} 
//sort button validation
@Test(priority = 7)
public void sortbutton() {
WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
WebElement searchbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@aria-autocomplete='list']")));
Assert.assertTrue(searchbutton.isDisplayed(),"Button is not displayed");
Assert.assertTrue(searchbutton.isEnabled(), "Button is not enabled");
}

     
@Test(priority = 8)
public void sortplaceholder() {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	WebElement sortbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@aria-autocomplete='list']")));
	
// Retrieve the placeholder attribute
    String placeholderText = sortbutton.getAttribute("placeholder");
// Expected placeholder text
    String expectedPlaceholder = "Sort by:Recently allocated";
// Validate the placeholder
    if (placeholderText.equals(expectedPlaceholder)) {
        System.out.println("Sort placeholder text is correct: " + placeholderText);
    } else {
        System.out.println("Sort placeholder text is incorrect. Found: " + placeholderText);
    }
} 

	

    //Business count button
@Test(priority = 9)
public void businessess() {
WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
WebElement count = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='font-weight-bold text-muted py-2 px-3']")));
Assert.assertTrue(count.isDisplayed(),"Button is not displayed");
Assert.assertTrue(count.isEnabled(), "Button is not enabled");
Assert.assertEquals(count.getText(), "23 businesses", "Text is not matched");
}	

//Table validation

//Locate the table

		@Test(priority = 10)
		public void table() {
			try {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-response pb-3']")));
			
// Extract all rows of the table
	        List<WebElement> rows = table.findElements(By.tagName("tr"));

// Loop through rows to find the required data
	        boolean isDataFound = false;
	        for (WebElement row : rows) {
// Extract all cells in the current row
	        List<WebElement> cells = row.findElements(By.tagName("td"));

// Check if the desired cell data matches
	         for (WebElement cell : cells) {
	                String cellText = cell.getText();
	                System.out.println("Cell Data: " + cellText); 

	                if (cellText.equals("ExpectedValue")) {
	                    isDataFound = true;
	                    break;
	                }
	            }

	            if (isDataFound) {
	                break;
	            }
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }}
		
}


