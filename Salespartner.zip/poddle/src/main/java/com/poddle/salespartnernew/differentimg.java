package com.poddle.salespartnernew;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class differentimg extends setup {

	@Test(priority = 5)
	public void imageupload()  throws InterruptedException {
		try {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-camera']")));
       image.click();
	
	String file="C:\\Users\\aksaj\\OneDrive\\football-730418_1280.jpg";
	StringSelection selection = new StringSelection(file);

    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
	
    Thread.sleep(500);
   Robot robot = new Robot();
   robot.keyPress(KeyEvent.VK_CONTROL);
   robot.keyPress(KeyEvent.VK_V);
   robot.keyRelease(KeyEvent.VK_V);
   robot.keyRelease(KeyEvent.VK_CONTROL);
   Thread.sleep(500);
   robot.keyPress(KeyEvent.VK_ENTER);
   robot.keyRelease(KeyEvent.VK_ENTER);
   
   
	  } catch (AWTException e) {
            System.out.println("AWTException occurred: " + e.getMessage());
	            e.printStackTrace(); 


		}}
	//Again upload a image
	@Test(priority = 6)
	public void imageupload1()  throws InterruptedException {
		try {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[@for='file-upload1']")));
       image.click();
	
	
		
	String file2="C:\\Users\\aksaj\\OneDrive\\macarons-1850216_1280.jpg";
	StringSelection selection = new StringSelection(file2);

    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
	
    Thread.sleep(500);
   Robot robot = new Robot();
   robot.keyPress(KeyEvent.VK_CONTROL);
   robot.keyPress(KeyEvent.VK_V);
   robot.keyRelease(KeyEvent.VK_V);
   robot.keyRelease(KeyEvent.VK_CONTROL);
   Thread.sleep(2000);
   robot.keyPress(KeyEvent.VK_ENTER);
   robot.keyRelease(KeyEvent.VK_ENTER);
   
   
	  } catch (AWTException e) {
            System.out.println("AWTException occurred: " + e.getMessage());
	            e.printStackTrace(); 


		}}
      //click confirm
			@Test(priority = 11)
			public void clickconfirm() {
				WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		        WebElement confirm = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Confirm']")));
		        confirm.click();
			}  
			//click save
		        @Test(priority = 12)
		        public void savechanges() {
		        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		        WebElement save = wait.until(ExpectedConditions.elementToBeClickable(By.id("save-changes")));
		       save.click();     
			}
	      
	        
		

}
