package com.poddle.salespartnernew;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Login2 extends setup {


	 @Test
	 public void browse() {
	 driver.get("https://www.google.com");
	 driver.get("https://sales-partner.poddleuat.demotown.co.uk/#/diary/calendar");
	 }
	 
	 @Test
		public void signinE() {
							
			WebElement emailField = driver.findElement(By.id("login-email"));
			emailField.sendKeys("aksaja50@gmail.com");
			WebElement passwordField = driver.findElement(By.id("login-password"));
			passwordField.sendKeys("WgemWgem@23");
			WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
			unhidepass.click();
			WebElement rememberme = driver.findElement(By.cssSelector("label[for='rememberMeCheck']"));
			rememberme.click();
			WebElement button = driver.findElement(By.id("login-btn"));
		    button.click();

}}
