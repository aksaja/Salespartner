package com.poddle.salespartnernew;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;

public class Login extends setup{

	
	
	 @Test
	 public void browse() {
	 driver.get("https://www.google.com");
	 driver.get("https://sales-partner.poddleuat.demotown.co.uk/#/diary/calendar");
	 }
	@Test(priority = 1)
	public void signin1(){
		
		 WebElement emailField = driver.findElement(By.id("login-email"));
		 emailField.sendKeys("aksaja5@gmail.com");
		 WebElement passwordField = driver.findElement(By.id("login-password"));
		 passwordField.sendKeys("87654321");
		 WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
		 unhidepass.click();
		 WebElement button = driver.findElement(By.id("login-btn"));
		 button.click();
		 driver.manage().timeouts().implicitlyWait(20, java.util.concurrent.TimeUnit.SECONDS);
		 emailField.clear();
		 passwordField.clear();
	}
	
	@Test(priority = 2)
    public void signin2() {
		
		 WebElement emailField = driver.findElement(By.id("login-email"));
		 emailField.sendKeys("aksaja50@gmail.com");
		 WebElement passwordField = driver.findElement(By.id("login-password"));
		 passwordField.sendKeys("87654321");
		 WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
		 unhidepass.click();
		 WebElement button = driver.findElement(By.id("login-btn"));
		 button.click();
	     driver.manage().timeouts().implicitlyWait(20, java.util.concurrent.TimeUnit.SECONDS);
	     emailField.clear();
	     passwordField.clear();
	}
	
	@Test(priority = 3)
    public void signin3() {
				
		WebElement emailField = driver.findElement(By.id("login-email"));
		emailField.sendKeys("aksaja5@gmail.com");
		WebElement passwordField = driver.findElement(By.id("login-password"));
		passwordField.sendKeys("WgemWgem@23");
		WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
		unhidepass.click();
		WebElement button = driver.findElement(By.id("login-btn"));
		button.click();
	    driver.manage().timeouts().implicitlyWait(20, java.util.concurrent.TimeUnit.SECONDS);
	    emailField.clear();
	    passwordField.clear();
	}
	
	@Test(priority = 4)
	public void signin4() {
						
		WebElement emailField = driver.findElement(By.id("login-email"));
		emailField.sendKeys("thuriga3@gmail.com");
		WebElement passwordField = driver.findElement(By.id("login-password"));
		passwordField.sendKeys("WgemWgem@23");
		WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
		unhidepass.click();
		WebElement rememberme = driver.findElement(By.cssSelector("label[for='rememberMeCheck']"));
		rememberme.click();
		WebElement button = driver.findElement(By.id("login-btn"));
	    button.click();
			 
}
//	@Test(priority = 5) 
//	public void logout() {
//		WebElement logoutfield = driver.findElement(By.id("user-drop"));
//		logoutfield.click();
//		WebElement logout = driver.findElement(By.id("logout"));
//		logout.click();
//	}

}

	





	



	


