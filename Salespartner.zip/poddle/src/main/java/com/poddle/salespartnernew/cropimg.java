package com.poddle.salespartnernew;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class cropimg extends setup{
//	 @Test(priority = 4)		
//		public void clickprofile() {
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
//	        WebElement profile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Profile']")));
//	       profile.click();
//	    }	
		

		
		@Test(priority = 1)
		public void imageupload()  throws InterruptedException {
			try {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@class='fa fa-camera']")));
	       image.click();
		
		 //Thread.sleep(3000);
			
		String file="C:\\Users\\aksaj\\OneDrive\\football-730418_1280.jpg";
		StringSelection selection = new StringSelection(file);

	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
	   Thread.sleep(500);
	   Robot robot = new Robot();
	   robot.keyPress(KeyEvent.VK_CONTROL);
	   robot.keyPress(KeyEvent.VK_V);
	   robot.keyRelease(KeyEvent.VK_V);
	   robot.keyRelease(KeyEvent.VK_CONTROL);
	   Thread.sleep(500);
	   robot.keyPress(KeyEvent.VK_ENTER);
	   robot.keyRelease(KeyEvent.VK_ENTER);
	   
			  } catch (AWTException e) {
		            System.out.println("AWTException occurred: " + e.getMessage());
		            e.printStackTrace(); 
		

			}}

		//Click crop
	        @Test(priority = 2)
	        public void clickcrop() {
	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	        WebElement crop = wait.until(ExpectedConditions.elementToBeClickable(By.id("croped-id-btn")));
	        crop.click();  
	        System.out.println("Crop button clicked successfully.");
	        }
	        
	      //Click image ratio buttons
	        @Test(priority = 3)
	        public void clickratio1() {
	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	        WebElement ratio1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("imageRatio2")));
	        ratio1.click(); 
	        }
	        
	        @Test(priority = 4)
	        public void clickratio2() {
	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	        WebElement ratio2 = wait.until(ExpectedConditions.elementToBeClickable(By.id("imageRatio3")));
	        ratio2.click(); 
	        } 
	        
	      //Click rotate
	        
	        @Test(priority = 5)
	        public void clickrotate() {
	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	        WebElement rotate = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='rotate-btn']")));
	        rotate.click(); 
	        } 
	        
	        //click save
	        @Test(priority = 6)
	        public void clicksave() {
	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	        WebElement savechanges = wait.until(ExpectedConditions.elementToBeClickable(By.id("save-btn-changes")));
	        savechanges.click(); 
	        } 
	        
		     //click confirm
				@Test(priority = 7)
				public void clickconfirm() {
					WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
			        WebElement confirm = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Confirm']")));
			        confirm.click();
				}  
			// click save
			        @Test(priority = 9)
			        public void savechanges() {
			        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
			        WebElement save = wait.until(ExpectedConditions.elementToBeClickable(By.id("save-changes")));
			       save.click();     
				}

}
