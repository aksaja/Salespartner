package com.poddle.salespartnernew;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class setup {

protected static WebDriver driver;
	
	@BeforeSuite

	public void setupsuite() {
	
		 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
	}	 
//		 @Test
//		 public void browse() {
//		 driver.get("https://www.google.com");
//		 driver.get("https://sales-partner.poddleuat.demotown.co.uk/#/diary/calendar");
//	}
	 @AfterSuite
	    public void tearDown() {
	        if (driver != null) {
	            driver.quit(); // Close the browser after the tests are finished
	        }}}

