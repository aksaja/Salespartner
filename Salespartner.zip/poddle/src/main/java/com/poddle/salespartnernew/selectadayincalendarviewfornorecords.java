package com.poddle.salespartnernew;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class selectadayincalendarviewfornorecords extends setup {

	//Click calendar and select a date
		@Test(priority = 5)
		public void clickcalendar() throws InterruptedException{
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".input-group-text.bg-white")));
			click.click();
			Thread.sleep(3000);
		}
		
		@Test(priority = 6)
		public void selectadate() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement dateselection = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div[aria-label='Sunday, December 8, 2024'] span[class='custom-day']")));
			//dateselection.click();
		  System.out.println("Date element is clickable");
		  
				
	        Actions actions = new Actions(driver);
	        actions.doubleClick(dateselection).perform();
	        System.out.println("Double-click action performed");
		}
		
		//Locate the table
		
		@Test(priority = 8)
		public void table() {
			try {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-response pb-3']")));
			
		
		    // Extract all rows of the table
	        List<WebElement> rows = table.findElements(By.tagName("tr"));

	        // Loop through rows to find the required data
	        boolean isDataFound = false;
	        for (WebElement row : rows) {
	            // Extract all cells in the current row
	            List<WebElement> cells = row.findElements(By.tagName("td"));

	            // Check if the desired cell data matches
	            for (WebElement cell : cells) {
	                String cellText = cell.getText();
	                System.out.println("Cell Data: " + cellText); 

	                if (cellText.equals("ExpectedValue")) {
	                    isDataFound = true;
	                    break;
	                }
	            }

	            if (isDataFound) {
	                break;
	            }
	        }

	        // Assert that the data is found
	        Assert.assertTrue(isDataFound, "The expected data was not found in the table.");

	    } catch (Exception e) {
	        e.printStackTrace();
	    }}
		
}
		


