package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.AfterClass;


public class AddtimeslotN extends setup {
	



		@Test(priority = 6)
		public void timeslotb() {
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
			WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[class='btn p-button'] span[class='p-label-small']")));
			
			Assert.assertTrue(button.isDisplayed(), "Button is not displayed on the page");
			Assert.assertTrue(button.isEnabled(), "Button is not enabled");
			Assert.assertEquals(button.getText(),"Add timeslot","Button text doest not match");
		}
		
		
		@Test(priority = 7)
		public void timeslots() {
		
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1));
			WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='col-12 manage-availability-view'] span[class='title font-weight-bold p-sub-title-medium-odd']")));
		
		Assert.assertTrue(title.isDisplayed(),"Title is not displayed on the page");
		Assert.assertEquals(title.getText(),"Add some availability!");
		}

		
		@Test(priority = 8)
		public void timeslotsbo() {
			
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(1));
			WebElement bodytext = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='col-12 manage-availability-view'] span[class='p-label-large']")));
			
		Assert.assertTrue(bodytext.isDisplayed(), "Body text is not displayed");
		Assert.assertEquals(bodytext.getText(),"Add the first timeslot to your diary to make yourself available for meetings");
		}

}