package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class profiledetails extends setup{

	@Test(priority = 5)
	public void validateProfileDetails() {
	    // Expected values
	    String expectedfirstName = "Aksaja";
	    String expectedlastName = "Thuriga";
	    String expectedEmail = "aksaja50@gmail.com";
	    String expectedLocation1 = "Bolton",expectedLocation2 = "Bristol";

	    // Locate and extract profile details
	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	    WebElement firstnameElement = wait.until(ExpectedConditions.elementToBeClickable(By.id("first-name")));
	    //WebElement firstnameElement = driver.findElement(By.id("first-name"));
	    WebElement lastnameElement = driver.findElement(By.id("last-name"));
	    WebElement emailElement = driver.findElement(By.id("sales-partner-email")); 
	    WebElement locationElement = driver.findElement(By.xpath("//div[@class='border rounded disable-location p-bg-light d-flex align-items-center p-border-radios m-rad-8']")); // Replace with actual locator

	    String actualfirstName = firstnameElement.getText();
	    String actuallastName = lastnameElement.getText();
	    String actualEmail = emailElement.getText();
	    String actualLocations = locationElement.getText();

	    // Validate each detail
	    Assert.assertEquals(actualfirstName, expectedfirstName, "Name does not match!");
	    Assert.assertEquals(actuallastName, expectedlastName, "Name does not match!");
	    Assert.assertEquals(actualEmail, expectedEmail, "Email does not match!");
	    Assert.assertTrue(actualLocations.equals(expectedLocation1) || actualLocations.equals(expectedLocation2), "Location does not match!");
	    System.out.println("Actual value: " + actualfirstName);
}}
