package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test2 {

	WebDriver driver;

	@Test(priority = 1)

	public void setupsuite()  throws InterruptedException{
	
		 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
	}	
	@Test(priority = 2)
	 public void browse() {
	 driver.get("https://www.google.com");
	 driver.get("https://sales-partner.poddleuat.demotown.co.uk/#/diary/calendar");
	 }

	@Test(priority = 3)
	public void signin4() {
						
		WebElement emailField = driver.findElement(By.id("login-email"));
		emailField.sendKeys("thuriga3@gmail.com");
		WebElement passwordField = driver.findElement(By.id("login-password"));
		passwordField.sendKeys("WgemWgem@23");
		WebElement unhidepass = driver.findElement(By.cssSelector(".input-group-text.p-border-radius-right.border-left-0.c-point"));
		unhidepass.click();
		WebElement rememberme = driver.findElement(By.cssSelector("label[for='rememberMeCheck']"));
		rememberme.click();
		WebElement button = driver.findElement(By.id("login-btn"));
	    button.click();
	    //Thread.sleep(2000);
	}
//	
//	@Test(priority = 4)
//	public void timeslotb() {
//		
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[class='btn p-button'] span[class='p-label-small']")));
//		
//		Assert.assertTrue(button.isDisplayed(), "Button is not displayed on the page");
//		Assert.assertTrue(button.isEnabled(), "Button is not enabled");
//		Assert.assertEquals(button.getText(),"Add timeslot","Button text doest not match");
//	}
//	
//	
//	@Test(priority = 5)
//	public void timeslots() {
//	
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1));
//		WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='col-12 manage-availability-view'] span[class='title font-weight-bold p-sub-title-medium-odd']")));
//	
//	Assert.assertTrue(title.isDisplayed(),"Title is not displayed on the page");
//	Assert.assertEquals(title.getText(),"Add some availability!");
//	}
//
//	
//	@Test(priority = 6)
//	public void timeslotsbo() {
//		
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(1));
//		WebElement bodytext = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='col-12 manage-availability-view'] span[class='p-label-large']")));
//		
//	Assert.assertTrue(bodytext.isDisplayed(), "Body text is not displayed");
//	Assert.assertEquals(bodytext.getText(),"Add the first timeslot to your diary to make yourself available for meetings");
//	}
//
//	@Test(priority = 9)
//	public void addtimeslot() {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='p-label-small'][normalize-space()='Add timeslot']")));
//		button.click();
//		
//	}
//	
//	@Test(priority = 10)
//	public void title() {
//	WebElement title = driver.findElement(By.cssSelector("div[class='col-sm-12 col-md-12 col-lg-6 col-12 manage-availability-view add-availability'] span[class='title font-weight-bold']"));
//	Assert.assertTrue(title.isDisplayed(), "Title is not displayed on the popup");
//	Assert.assertEquals(title.getText(), "Add Availability");
//
//	}
//    @Test(priority = 11)
//    public void date() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement date = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='input-group-text bg-white']//*[name()='svg']//*[name()='path' and contains(@d,'M2.5 4a.5.')]")));
//        date.click();
//    }
//    @Test(priority = 12)
//    public void customeday() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement customday = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[aria-label='Saturday, November 30, 2024'] span[class='custom-day']")));
//        customday.click();     
//}
//    @Test(priority = 13)
//    public void selecttime() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement select = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='12:30 AM'] ")));
//        select.click();  
//    }
//    
//    @Test(priority = 14)
//    public void clicktime() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement clicktime = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='input-group-append']//span[@class='input-group-text p-border-radius-right bg-white']//*[name()='svg']")));
//        clicktime.click();  
//    }
//    @Test(priority = 15)
//    public void endtime() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement end = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='inputEndTime-sizing-lg'] ")));
//        end.click(); 
//    }
//    
//    @Test(priority = 16)
//    public void duration() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement durationvalidation = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Duration 30 minutes')] ")));
//        durationvalidation.click(); 
//    }
//    
//    
//    @Test(priority = 17)
//    public void button() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
//		WebElement addbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='row mt-3 mb-5'] button[class='btn p-button m-p-button w-100']")));
//        addbutton.click(); 
//    }
    
    @Test(priority = 13)
    public void delete() throws InterruptedException{
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
		WebElement delete = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[name()='path' and contains(@d,'M16 8A8 8 ')]")));
        Thread.sleep(1000);
		delete.click();	
    }
 
    @Test(priority = 14)
    public void deleteavailable() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
		WebElement yesbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='Yes']")));
        yesbutton.click();
    }
////close the delete availability popup without delete
//    //click the cancel
//    @Test(priority = 13)
//    public void cancel() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
//		WebElement cancel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='Saturday-2024-11-30-200']//span[@class='c-point ng-star-inserted']//*[name()='svg']")));
//        cancel.click();	
//    } 
////click close icon on the popup
//    @Test(priority = 13)
//    public void closeicon() {
//    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
//		WebElement close = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='close-cancel-schedule']//i[@class='fa fa-times']")));
//        close.click();	
//  
}



