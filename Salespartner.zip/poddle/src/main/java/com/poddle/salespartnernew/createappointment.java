package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class createappointment extends setup{
	//Click create
 @Test(priority = 4)
 public void create() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    WebElement create = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='p-label-small']")));
		create.click(); 
 }
 //Select a date
 @Test(priority = 5)
 public void date() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    WebElement date = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='btn-light bg-primary text-white']")));
		date.click(); 
 }
 
 
 //select a time slot
 @Test(priority = 6)
 public void timeslot() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    WebElement time = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='8:00 am']")));
		time.click(); 
 }
 //Click add appointment
 @Test(priority = 7)
 public void add() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    WebElement appointment = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add appointment']")));
		appointment.click(); 
 }
 //Click Okay on the pop up
 @Test(priority = 7)
 public void okay() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	    WebElement okay = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Okay']")));
		okay.click(); 
 }


}
