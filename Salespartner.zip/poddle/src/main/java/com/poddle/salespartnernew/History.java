package com.poddle.salespartnernew;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class History extends setup{
	//click history
		@Test(priority = 4)
		public void clickHistory() throws InterruptedException{
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		    WebElement click = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='canceled-text canceled-btn font-weight-bold']")));
		    click.click();
		    Thread.sleep(1000);
		}
		//Validate title
		@Test(priority = 4)
		public void title() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		    WebElement titleText = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Meeting History')]")));
			Assert.assertTrue(titleText.isDisplayed(),"Title text is not displayed");
			Assert.assertEquals(titleText.getText(), "Meeting History","Title text is not matched");
		}
		//Validate sub title
		@Test(priority = 5)
		public void subtitle() {
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		    WebElement subtitleText = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Tuesday, 10 December 2024 at 8:00 AM')]")));
			Assert.assertTrue(subtitleText.isDisplayed(),"Sub title text is not displayed");
		}
		//Close the popup
			@Test(priority = 6)
			public void closePopup() {
				WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
			    WebElement closePopup = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='close-meeting-history']//i[@class='fa fa-times']")));
	            closePopup.click();
			}
			//Validate the history table
			@Test(priority = 7)
			public void table() {
				WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
			    WebElement table = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='table-responsive-md mb-4']")));
			    List<WebElement> rows = table.findElements(By.tagName("tr"));
			    boolean isDataFound = false;
		        for (WebElement row : rows) {
	// Extract all cells in the current row
		        List<WebElement> cells = row.findElements(By.tagName("td"));

	// Check if the desired cell data matches
		         for (WebElement cell : cells) {
		                String cellText = cell.getText();
		                System.out.println("Cell Data: " + cellText); 

		                if (cellText.equals("ExpectedValue")) {
		                    isDataFound = true;
		                    break;
		                }
		            }

		            if (isDataFound) {
		                break;
		            }
		        }
			}
				

}
