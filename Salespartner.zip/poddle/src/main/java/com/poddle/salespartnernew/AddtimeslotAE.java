package com.poddle.salespartnernew;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AddtimeslotAE extends setup{
	
	@Test(priority = 8)
	public void manage() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(1));
       
        WebElement manage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[class='btn p-light-button'] span[class='p-label-small']")));
        
        manage.click();
	}
	@Test(priority = 9)
	public void addtimeslot() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[id='add-availability-btn'] span[class='p-label-small']")));
		button.click();
		
	}
	
	@Test(priority = 10)
	public void title() {
	WebElement title = driver.findElement(By.cssSelector("div[class='col-sm-12 col-md-12 col-lg-6 col-12 manage-availability-view add-availability'] span[class='title font-weight-bold']"));
	Assert.assertTrue(title.isDisplayed(), "Title is not displayed on the popup");
	Assert.assertEquals(title.getText(), "Add Availability");

	}
    @Test(priority = 11)
    public void date() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement date = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("body > app-root:nth-child(1) > div:nth-child(1) > div:nth-child(3) > app-schedule-calendar:nth-child(2) > app-timeslot-form:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > form:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > span:nth-child(1) > svg:nth-child(1) > path:nth-child(2)")));
        date.click();
    }
    @Test(priority = 12)
    public void customeday() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement customday = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[aria-label='Saturday, November 30, 2024'] span[class='custom-day']")));
        customday.click();     
}
    @Test(priority = 13)
    public void selecttime() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement select = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[normalize-space()='12:30 AM'] ")));
        select.click();  
    }
    
    @Test(priority = 14)
    public void clicktime() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement clicktime = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='input-group-append']//span[@class='input-group-text p-border-radius-right bg-white']//*[name()='svg']")));
        clicktime.click();  
    }
    @Test(priority = 15)
    public void endtime() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement end = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='inputEndTime-sizing-lg'] ")));
        end.click(); 
    }
    
    @Test(priority = 16)
    public void duration() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement durationvalidation = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Duration 30 minutes')] ")));
        durationvalidation.click(); 
    }
    
    
    @Test(priority = 17)
    public void button() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); 
		WebElement addbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='row mt-3 mb-5'] button[class='btn p-button m-p-button w-100']")));
        addbutton.click(); 
    }
    
    }


